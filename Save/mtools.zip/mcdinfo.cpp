/************************************************************************ 
  MCDINFO  Get CD Information              v00.10.00
  Forever Young Software      Benjamin David Lunt

  This utility was desinged for use with Bochs to get the
    info from a CDROM.

  Bochs is located at:
    http://bochs.sourceforge.net

  I designed this program to be used for testing my own OS,
   though you are welcome to use it any way you wish.

  Please note that I release it and it's code for others to
   use and do with as they want.  You may copy it, modify it,
   do what ever you want with it as long as you release the
   source code and display this entire comment block in your
   source or documentation file.
   (you may add to this comment block if you so desire)

  Please use at your own risk.  I do not specify that this
   code is correct and unharmful.  No warranty of any kind
   is given for its release.

  I take no blame for what may or may not happen by using
   this code with your purposes.

  'nuff of that!  You may modify this to your liking and if you
   see that it will help others with their use of Bochs, please
   send the revised code to fys@cybertrails.com.  I will then
   release it as I have this one.

  P.S.  Please don't laugh at my code :)  I didn't spend but
   a few minutes on this.  BXimage just wasn't working for my
   needs, so here it is.

  You may get the latest and greatest at:
    http://www.cybertrails.com/~fys/mtools.htm

  Thanks, and thanks to those who contributed to Bochs....

  ********************************************************

  Things to know:
  - 
  
  ********************************************************

  Compiles as is with MS VC++ 6.x         (Win32 .EXE file)

	// ****** I am sure it will.  You just have to copy all those
	//   Windows.h files.... yeekkk.
  To compile using DJGPP:  (http://www.delorie.com/djgpp/)
     gcc -Os mkdosfs.c -o mkdosfs.exe -s  (DOS .EXE requiring DPMI)

	// ****** Requires an NT machine.  No DOS support here *****
  //Compiles as is with MS QC2.5            (TRUE DOS only)


  ********************************************************

  Usage:
    Nothing.  Just run it...

************************************************************************/

// don't know which ones are needed or not needed.  I just copied them
//  across from another project. :)
#include <ctype.h>
#include <conio.h>
#include <stdio.h>
#include <errno.h>
#include <memory.h>
#include <stdlib.h>
#include <string.h>
#include <stddef.h>
#include <limits.h>
#include <math.h>
#include <time.h>

#include <windows.h>

#include "mcdinfo.h"   // our include

#define CD_FRAMESIZE 2048

HANDLE hFile;
char drive[16], temp[128], drvletter;
unsigned long ntemp, pos, n;
unsigned char *pathtable;
int i, j;


//// ***** WARNING.  At current, this only works on NT machines **********

int main() {

	// print start string
	fprintf(stderr, strtstr);

	fprintf(stderr, "\n *** Warning.  This currently only works on WinNT machines ***");
	fprintf(stderr, "\n   Continue (Yes or No): ");
	gets(temp);
	if (strcmp(temp, "Y") && strcmp(temp, "Yes") && strcmp(temp, "YES"))
		return 0xFF;

	do {
		fprintf(stderr, "\n                         Drive letter [d]: ");
		gets(temp);
		if (!strlen(temp))
			drvletter = 'd';
		else
			drvletter = tolower(temp[0]);
	} while ((drvletter < 'd') || (drvletter > 'z'));
	sprintf(drive, "\\\\.\\%c:", drvletter);

	hFile = CreateFile((char *)&drive, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_FLAG_RANDOM_ACCESS, NULL); 
	if (hFile == (void *)0xFFFFFFFF) {} // TODO: error

	pos = SetFilePointer(hFile, (16*CD_FRAMESIZE), NULL, SEEK_SET);
	ReadFile(hFile, (void *) &pvd, CD_FRAMESIZE, (unsigned long *) &ntemp, NULL);
	if (ntemp == 0) {} // TODO: error
	
	memset(temp, 0, sizeof(temp));
	memcpy(temp, pvd.ident, 5);
	printf("\n                  Type: %i"
		   "\n  Standard Identifier:  %5s"
		   "\n   Descriptor Version:  %i"
		   "\n   Logical Block size:  %i"
		   "\n    Sectors in volume:  %i (%3.2f meg)"
		   "\n",
		   pvd.type, temp, pvd.ver, pvd.lba_size,
		   pvd.num_lbas, (double) ((double) pvd.num_lbas / 512)
		   );

	ntemp = (pvd.path_table_size / CD_FRAMESIZE) + (pvd.path_table_size % CD_FRAMESIZE ? 1 : 0); 
	printf("\n  *** Path Table  ***"
		   "\n             Location:  %i"
		   "\n      Path Table size:  %i  (%i sectors)"
		   "\n",
		   pvd.PathL_loc, pvd.path_table_size, ntemp
		   );

	printf("\n  *** Root  ***"
		   "\n             Location:  %i"
		   "\n               Length:  %i  (%i sectors)"
		   "\n                Flags:  %02X"
		   "\n",
		   pvd.root.extent_loc, pvd.root.data_len, 
		   ((pvd.root.data_len / CD_FRAMESIZE) + (pvd.root.data_len % CD_FRAMESIZE ? 1 : 0)),
		   pvd.root.flags
		   );

	pathtable = (unsigned char *) calloc(CD_FRAMESIZE*ntemp, sizeof(unsigned char));
	if (pathtable == NULL) {} // TODO: error
	pos = SetFilePointer(hFile, (pvd.PathL_loc*CD_FRAMESIZE), NULL, SEEK_SET);
	ReadFile(hFile, (void *) pathtable, CD_FRAMESIZE*ntemp, (unsigned long *) &ntemp, NULL);
	if (ntemp == 0) {} // TODO: error

	j = 0;
	ntemp = 0;
	do {
		memset(temp, 0, 128);
		for (i=0; i<(unsigned char) *pathtable; i++)
			temp[i] = (char) *(pathtable+8+i);
		printf("\n Path Table Entry %i"
			   "\n   Logical Block: %i"
			   "\n          Parent: %i"
			   "\n      Identifier: %s"
			   "\n",
			   j++, (unsigned short) *(pathtable+2),
			   (unsigned short) *(pathtable+6), temp
			   );
		i = 8;
		i += (unsigned char) *pathtable;
		i += (unsigned char) *pathtable & 1;
		pathtable += i;
		ntemp += i;
	} while (ntemp < pvd.path_table_size);

	CloseHandle(hFile);
	
	return 0x00;
}
